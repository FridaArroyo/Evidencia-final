package evidencia;

public class Paciente {
    public Paciente(String n){
        nombre =n;
    }

    public String toString(){
        return "Paciente: " + nombre;
    }

    private String nombre;
}